#PLOT TRENDS

trends<-read.table('trends.txt')

trends$V3[trends$V3==1]<-"Males"
trends$V3[trends$V3==2]<-"Females"
trends$V3[trends$V3==3]<-"WP"

trends$Type<-"Partitioned"
trends$Type[trends$V3=="WP"]<-"Whole popilation"

trends$Type = factor(trends$Type, levels=c('Whole popilation','Partitioned'))

trends$V3 <- factor(trends$V3,levels = c("WP","Males","Females"))

cols<- (scales::hue_pal()(3))
names(cols)<- c("WP","Males","Females")

library(ggplot2)

ggplot(trends, aes(x=as.factor(V4), y=V5, group=V3,fill=V3,color=V3)) +
  geom_line(show.legend = F)+
  geom_ribbon(aes(ymin=V5-2*V6,ymax=V5+2*V6, fill=V3,group=V3),alpha=.15,colour = NA)+
  labs(x="Generation", y="Genetic value", fill=element_blank(),title = element_blank())+
  guides(fill=guide_legend(title=NULL,override.aes = list(alpha=1)))+
  #lims(y=limites[[trait]])+
  facet_grid( Type ~ .)+
  scale_fill_manual(values = cols,
                    breaks = c("WP","Males","Females"),
                    drop=T)+
  theme(legend.position = "bottom", legend.direction = "horizontal")

#PLOT DENSITY
t1<-read.table('trends_trait_1_1')

colnames(t1) <- c("iter","group",paste("G",1:(ncol(t1)-2),sep=""))


df <- rbind(data.frame(Group="Males",Generation= "5-1", value = c(t1$G5-t1$G1)[t1$group=="1"]),
            data.frame(Group="Females",Generation= "5-1", value = c(t1$G5-t1$G1)[t1$group=="2"]),
            data.frame(Group="WP",Generation= "5-1", value = c(t1$G5-t1$G1)[t1$group=="TOT"]),
            data.frame(Group="Males",Generation= "10-6", value = c(t1$G10-t1$G6)[t1$group=="1"]),
            data.frame(Group="Females",Generation= "10-6", value = c(t1$G10-t1$G6)[t1$group=="2"]),
            data.frame(Group="WP",Generation= "10-6", value = c(t1$G10-t1$G6)[t1$group=="TOT"]))
df$Group <- factor(df$Group,levels = c("WP","Males","Females"))

ggplot(df, aes(x=value) ) +
  # Top
  geom_density( aes(x = value,fill=Group),alpha=0.5 ,show.legend = T) +
  facet_grid(Generation ~ .,
             scales = "free_x")+
  theme(legend.position = "bottom", legend.direction = "horizontal")+
  labs(x="Genetic value", y="Density", fill=element_blank(),title = element_blank())

#PLOT RESPONSE TO SELECTION

df <- t1 

df[,4:ncol(df)] <- df[,4:ncol(df)] - df[,(4:ncol(df))-1]

calc_positive<-function(x){
  length(x[x>0])/length(x)
}

df_TOT<-df[df$group=="TOT",]
df_1<-df[df$group=="1",]
df_2<-df[df$group=="2",]

df <- rbind(data.frame(Group="WP",Generation=2:10,y2.5 = apply(df_TOT[,4:ncol(df)],2, quantile,probs= 0.025),
                       y50 = apply(df_TOT[,4:ncol(df)],2,median), y97.5=apply(df_TOT[,4:ncol(df)],2, quantile,probs= 0.975),
                       prob = apply(df_TOT[,4:ncol(df)],2,calc_positive)),
            data.frame(Group="Males",Generation=2:10,y2.5 = apply(df_1[,4:ncol(df)],2, quantile,probs= 0.025),
                       y50 = apply(df_1[,4:ncol(df)],2,median), y97.5=apply(df_1[,4:ncol(df)],2, quantile,probs= 0.975),
                       prob = apply(df_1[,4:ncol(df)],2,calc_positive)),
            data.frame(Group="Females",Generation=2:10,y2.5 = apply(df_2[,4:ncol(df)],2, quantile,probs= 0.025),
                       y50 = apply(df_2[,4:ncol(df)],2,median), y97.5=apply(df_2[,4:ncol(df)],2, quantile,probs= 0.975),
                       prob = apply(df_2[,4:ncol(df)],2,calc_positive)))

df$Generation<-as.factor(df$Generation)
df$Group<-factor(df$Group,levels = c("WP","Males","Females"))
df$prob<-format(round(df$prob,2), nsmall = 2)
df$prob_text<-df$y97.5+0.4


ggplot(df) + 
  geom_boxplot(aes(x=Generation,ymin = y2.5, lower = y2.5, middle = y50, upper = y97.5, ymax = y97.5,fill=Group),
               stat = "identity", show.legend = F)+
  facet_grid(Group~.)+
  ylim(-1,4)+
  geom_text(aes(x=Generation,y=prob_text,label=prob),angle=0,size=3)+
  labs(y="Genetic value", x="Generation", fill=element_blank(),title = element_blank())

